import Cabecera from "components/Cabecera/Cabecera";
import Pie from "components/Pie";

function Inicio() {
  return (
    <>
      <Cabecera></Cabecera>
     
      <Pie />
    </>
  );
}

export default Inicio;
